This project repository contains program that reconstructs the original image 
from several rectangular puzzle pieces. It also contains some images to test.
We have 6 by 6, 7 by 7 and 8 by 8 small pieces.

instruction:
Run the maim.m file directly to start the program.
All shuffled and rotated small pieces will be displayed in the first figure.
Later on, reassembled long pieces and the whole image will also be displayed.

note:
By default it runs all 3 different sizes (i.e. reconstructs for 3 times).
If you want to have a look at one of them, please comment the other code parts.
(See comments in main.m for more detail)
